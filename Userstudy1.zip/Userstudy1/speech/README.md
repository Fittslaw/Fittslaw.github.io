# FittsLawExp
Fitts law experiment for HCI CS 522
This is an experiment setup to study the Fitts law as part of the HCI course at UIC. 

The experiment is setup with mouse as the input modality. It is a multi directional tapping task. 
The experiment has options of 3 distances and 2 differnet target widths. 
At the end of the experiment, the data can be downloaded in a csv format as well.
